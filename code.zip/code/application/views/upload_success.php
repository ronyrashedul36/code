<html>
<head>
<title>Upload Form</title>
</head>
<body>
  
 <hr>
<h3>Your file was successfully uploaded!</h3>
<img src="<?php echo $img[1]['full_path'];?>" alt="image">
<hr>
<ul>
<?php foreach ($upload_data as $item => $value):?>
<li><?php echo $item;?>: <?php echo $value;?></li>
<?php endforeach; ?>
</ul>

<p><?php echo anchor('upload', 'Upload Another File!'); ?></p>

</body>
</html>
<?php

class imgModel extends CI_model
{

    function create($data)
    {
        $this->db->insert('image', array('full_path' => $data));
    }
    function all()
    {
        return $users = $this->db->get('image')->result_array();
    }

}
?>